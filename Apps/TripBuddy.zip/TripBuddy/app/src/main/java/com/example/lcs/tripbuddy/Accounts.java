package com.example.lcs.tripbuddy;

import java.util.ArrayList;

/**
 * Created by lcs on 7/20/2017.
 */

public class Accounts extends ArrayList<Account>{

}
