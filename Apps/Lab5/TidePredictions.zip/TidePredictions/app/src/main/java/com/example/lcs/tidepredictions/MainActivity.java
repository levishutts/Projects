package com.example.lcs.tidepredictions;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by lcs on 7/15/2017.
 */

public class MainActivity extends Activity
        implements AdapterView.OnItemClickListener {

    private TideItems tideItems;
    static final String DATE = "date";
    static final String DAY = "day";
    static final String HIGHLOW = "highLow";
    static final String TIME = "time";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FileIO io = new FileIO(getApplicationContext());
        tideItems = io.readFile();

        ArrayList<HashMap<String, String>> data = new
                ArrayList<HashMap<String, String>>();

        for (TideItem item : tideItems)
        {
            HashMap<String, String> map = new HashMap<String, String>(2);
            map.put(DATE, item.getDate());
            map.put(DAY, item.getDay());
            map.put(HIGHLOW, item.getHighLow());
            map.put(TIME, item.getTime());
            data.add(map);
        }

        SimpleAdapter adapter = new SimpleAdapter(this, data,
                R.layout.listview_items,
                new String[]{DATE, DAY, HIGHLOW, TIME},
                new int[]{R.id.dateTextView, R.id.dayTextView, R.id.highLowTextView, R.id.timeTextView
                }
        );

        ListView itemsListView = (ListView)findViewById(R.id.tideListView);
        itemsListView.setAdapter(adapter);
        itemsListView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        TideItem item = tideItems.get(position);
        Toast.makeText(this,
                item.getFeet() + "ft\r\n" +
                        item.getCm() + "cm",
                Toast.LENGTH_LONG).show();
    }
}
