package com.example.lcs.tidepredictions;

import java.util.ArrayList;

/**
 * Created by lcs on 7/15/2017.
 */

public class TideItems extends ArrayList<TideItem> {
    // Extending ArrayList to facilitate possible future features

    // Default Serial ID
    private static final long serialVersionUID = 1L;
}
