package com.example.lcs.tidepredictions;

/**
 * Created by lcs on 7/19/2017.
 */

public enum Stations {
    TILLAMOOK, EMPIRE, FLORENCE
}
