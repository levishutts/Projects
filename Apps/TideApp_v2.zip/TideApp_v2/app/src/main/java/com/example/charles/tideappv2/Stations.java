package com.example.charles.tideappv2;

/**
 * Created by Charles on 7/17/2017.
 */

public enum Stations {
    ELKHORN, MONTEREY, SANTABARBARA
}
