import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JPanel;

public class PaintPanel extends JPanel {	
	private final ArrayList<SizePoint> _points;
	
	private Color _currentColor;
	private int _currentSize;
	
	public PaintPanel() {
		_points = new ArrayList<>();
		_currentColor = SizePoint.DEFAULT_COLOR;
		_currentSize = SizePoint.SMALL_SIZE;
		
		addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseDragged(MouseEvent ev) {
				_points.add(new SizePoint(ev.getPoint(), _currentSize, _currentColor));
				repaint();
			}
		});		
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		for (SizePoint p : _points) {
			p.paint(g);
		}
	}
	
	public void setCurrentColor(Color currentColor) {
		_currentColor = currentColor;
	}
	
	public void setCurrentSize(int currentSize) {
		_currentSize = currentSize;
	}
	
	public void clear() {
		_points.clear();
		repaint();
	}
}