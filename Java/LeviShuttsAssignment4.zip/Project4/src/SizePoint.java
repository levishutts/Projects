import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class SizePoint {
	public static final int SMALL_SIZE = 10;
	public static final int MEDIUM_SIZE = 25;
	public static final int LARGE_SIZE = 50;
	public static final Color DEFAULT_COLOR = Color.BLACK;

	private final Point _point;
	private final int _size;
	private final Color _color;
	
	public SizePoint(Point point, int size, Color color) {
		_point = point;
		_size = size;
		_color = color;
	}
	
	public Point getPoint() {
		return _point;
	}
	
	public int getSize() {
		return _size;
	}
	public Color getColor() {
		return _color;
	}
	
	public void paint(Graphics g) {
		g.setColor(_color);
		if (_size == SMALL_SIZE) {
			g.fillOval(_point.x, _point.y, SMALL_SIZE, SMALL_SIZE);
		} else if (_size == MEDIUM_SIZE) {
			g.fillOval(_point.x, _point.y, MEDIUM_SIZE, MEDIUM_SIZE);
		} else if (_size == LARGE_SIZE) {
			g.fillOval(_point.x, _point.y, LARGE_SIZE, LARGE_SIZE);
		} 
	}
}