import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame {	
	
	private final PaintPanel _paintPanel;
	private final JButton _blackButton;
	private final JButton _redButton;
	private final JButton _blueButton;
	private final JButton _greenButton;
	private final JButton _smallButton;
	private final JButton _mediumButton;
	private final JButton _largeButton;
	private final JButton _clearButton;
	
	public MainFrame() {		
		super("Main");
		setLayout(new BorderLayout());
		
		_paintPanel = new PaintPanel(); 
		add(_paintPanel, BorderLayout.CENTER);
		
		JPanel colorPanel = new JPanel();
		colorPanel.setLayout(new GridLayout(4, 1));
		
		_blackButton = new JButton("Black");
		_blackButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.setCurrentColor(Color.BLACK);
			}		
		});		
		colorPanel.add(_blackButton);
		
		_redButton = new JButton("Red");
		_redButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.setCurrentColor(Color.RED);
			}		
		});
		colorPanel.add(_redButton);
		
		_blueButton = new JButton("Blue");
		_blueButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.setCurrentColor(Color.BLUE);
			}		
		});
		colorPanel.add(_blueButton);		
		
		_greenButton = new JButton("Green");
		_greenButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.setCurrentColor(Color.GREEN);
			}		
		});
		colorPanel.add(_greenButton);
		
		add(colorPanel, BorderLayout.WEST);
		
		JPanel sizePanel = new JPanel();
		sizePanel.setLayout(new GridLayout(4, 1));
		
		_smallButton = new JButton("Small");
		_smallButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.setCurrentSize(SizePoint.SMALL_SIZE);
			}		
		});
		sizePanel.add(_smallButton);
		
		_mediumButton = new JButton("Medium");
		_mediumButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.setCurrentSize(SizePoint.MEDIUM_SIZE);
			}		
		});
		sizePanel.add(_mediumButton);

		_largeButton = new JButton("Large");
		_largeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.setCurrentSize(SizePoint.LARGE_SIZE);
			}		
		});
		sizePanel.add(_largeButton);
		
		_clearButton = new JButton("Clear");
		_clearButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_paintPanel.clear();
			}		
		});
		sizePanel.add(_clearButton);

		add(sizePanel, BorderLayout.EAST);
	}
}