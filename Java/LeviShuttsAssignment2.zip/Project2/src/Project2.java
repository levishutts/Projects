import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Project2 {
	
	private static ArrayList<Integer> RandDense(int length, double density) {
		
		//Takes an array length and a zero density double to create an array
		//of said length which creates a random amount of zeroes pertaining to the density.
		//non zero items are random numbers within the range of 1 to 1000000.
		
		ArrayList<Integer> list = new ArrayList<>(length);
		Random random = new Random();
		for (int i = 0; i < length; ++i) {
			if (random.nextDouble() < density) {		
				list.add(random.nextInt(1000000) + 1);
			} else {
				list.add(0);
			}
		}
		return list;
	}
	
	private static ArrayList<Object> RandSparse(int length, double density){
	
		//Takes an array length and a zero density double to iterate length amount of times
		//and based on the density, creates a nested list with the "index" and a number
		//between 1 and 1000000
		
		ArrayList<Object> list = new ArrayList<>(length);
		Random random = new Random();
		for (int i = 0; i < length; ++i) {
			ArrayList<Integer> sparse = new ArrayList<>(2);
			if (random.nextDouble() < density) {
				sparse.add(i);
				sparse.add(random.nextInt(1000000) + 1);
				list.add(sparse);
			}
		}
		return list;
	}
	
	private static ArrayList<Object> Dense2Sparse(ArrayList<Integer> dense){
		
		//Iterates through a dense array and adds the non zeroes and its index
		//to a nested list, creating a sparse array.
		
		ArrayList<Object> list = new ArrayList<>();
		for (int i = 0; i < dense.size(); ++i){
			if (dense.get(i) != 0){
				ArrayList<Integer> sparse = new ArrayList<>(2);
				sparse.add(i);
				sparse.add(dense.get(i));
				list.add(sparse);
			}
		}
		return list ;
	}
	
	private static ArrayList<Integer> Sparse2Dense(ArrayList<Object> sparse){
		
		//Iterates through a sparse array for the amount of times as the last nested array's
		//index value adding zeroes to fill in the gaps between the sparse array values,
		//creating a dense array
		int checkSize = sparse.size();
		if (checkSize == 0){
			ArrayList<Integer> list = new ArrayList<>();
			return list;
		}
		Object lastArray = sparse.get(sparse.size() - 1);
		ArrayList<Integer> lastArrayInt = new ArrayList<>(2);
		lastArrayInt = (ArrayList<Integer>) lastArray;
		ArrayList<Integer> list = new ArrayList<>(lastArrayInt.get(0));
		Integer count = 0;		
		for (int i = 0; i < lastArrayInt.get(0) + 1; ++i){
			Object sparseArray = sparse.get(count);
			ArrayList<Integer> nestedInts = new ArrayList<>(2);
			nestedInts = (ArrayList<Integer>) sparseArray;
			if (nestedInts.get(0) == i){
				list.add(nestedInts.get(1));
				count += 1;
			} else {
				list.add(0);
			}
		}
		return list;
	}
	
	private static ArrayList<Object> MaxDense(ArrayList<Integer> dense){
		
		//Finds the largest number in a dense array and returns said number
		//along with its index
		
		ArrayList<Object> list = new ArrayList<>(2);
		Integer max = 0;
		for (int i = 0; i < dense.size(); ++i){
			if (dense.get(i) > max){
				max = dense.get(i);
			}
		}
		list.add(max);
		list.add(dense.indexOf(max));
		return list;
	}
	
	private static ArrayList<Object> MaxSparse(ArrayList<Object> sparse){
		
		//Finds the largest number in a sparse array and returns said number
		//along with its index
		
		ArrayList<Object> list = new ArrayList<>(2);
		Integer max = 0;
		Integer index = 0;
		for (int i = 0; i < sparse.size(); ++i){
			Object sparseArray = sparse.get(i);
			ArrayList<Integer> nestedInts = new ArrayList<>(2);
			nestedInts = (ArrayList<Integer>) sparseArray;
			if (nestedInts.get(1) > max){
				max = nestedInts.get(1);
				index = nestedInts.get(0);
			}
		}
		list.add(max);
		list.add(index);
		return list;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter array length: ");
		int length = scanner.nextInt();
		System.out.println("Enter density: ");
		float density = scanner.nextFloat();
			
		while (length < 1){
			System.out.println("Not a valid length... (Must be > 0)");
			System.out.println("Enter array length: ");
			length = scanner.nextInt();
		}
		while (density <= 0 || density >= 1){
			System.out.println("Not a valid density... (Must be >= 0 and <= 1)");
			System.out.println("Enter density: ");
			density = scanner.nextFloat();
		}
			
			
		scanner.close();
		long startTime = System.nanoTime();
		ArrayList<Integer> dense = RandDense(length, density);
		long endTime = System.nanoTime() - startTime;
		System.out.println("create dense length: " + length + " time: " + endTime/1000000.0);
		
		startTime = System.nanoTime();
		ArrayList<Object> d2s = Dense2Sparse(dense);
		endTime = System.nanoTime() - startTime;
		System.out.println("dense to sparse length: " + d2s.size() + " time: " + endTime/1000000.0);
	
		startTime = System.nanoTime();
		ArrayList<Object> sparse = RandSparse(length, density);
		endTime = System.nanoTime() - startTime;
		System.out.println("create sparse length: " + length + " time: " + endTime/1000000.0);
		
		startTime = System.nanoTime();
		ArrayList<Integer> s2d = Sparse2Dense(sparse);
		endTime = System.nanoTime() - startTime;
		System.out.println("sparse to dense length: " + s2d.size() + " time: " + endTime/1000000.0);
		
		startTime = System.nanoTime();
		ArrayList<Object> maxDense = MaxDense(dense);
		endTime = System.nanoTime() - startTime;
		System.out.println("find max (dense): " + maxDense.get(0) + " at: " + maxDense.get(1));
		System.out.println("dense find time: " + endTime/1000000.0);
		
		startTime = System.nanoTime();
		ArrayList<Object> maxSparse = MaxSparse(sparse);
		endTime = System.nanoTime() - startTime;
		System.out.println("find max (sparse): " + maxSparse.get(0) + " at: " + maxSparse.get(1));
		System.out.println("sparse find time: " + endTime/1000000.0);
	}
	//Based off of different time tests with sizes of lengths and densities, I have concluded:
	//	-The longer the length is, the more efficient a random dense array is to a sparse array
	//	-Sparse max finds are far quicker than dense max finds
	//	-With high densities, dense to sparse lists are quicker than creating a random sparse itself
}