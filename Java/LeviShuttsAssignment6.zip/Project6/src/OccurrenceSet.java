import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class OccurrenceSet<T> implements Set<T>{

	private HashMap<T, Integer> hashmap;
	
	public OccurrenceSet() {
		hashmap = new HashMap<T, Integer>();
	}
	
	@Override
	public boolean add(T element) {
		if (!hashmap.containsKey(element)){
			hashmap.put(element, 1);
		} 
		else {
			hashmap.put(element, hashmap.get(element) + 1);
		}
		return false;
	}

	@Override
	public boolean addAll(Collection<? extends T> collection) {
		boolean modified = false;
		Iterator<? extends T> iter = collection.iterator();
		while (iter.hasNext()){
			if (add(iter.next())) {
				this.add(iter.next());
				modified = true;
			}
		}
		return modified;
	}

	@Override
	public void clear() {
		hashmap.clear();
	}

	@Override
	public boolean contains(Object element) {
		return hashmap.containsKey(element);
	}

	@Override
	public boolean containsAll(Collection<?> collection) {
		boolean contained = false;
		Iterator<?> iter = collection.iterator();
		while (iter.hasNext()){
			if (collection.contains(iter.next())) {
				contained = true;
			}
		}
		return contained;
	}

	@Override
	public boolean isEmpty() {
		return hashmap.isEmpty();
	}

	@Override
	public Iterator<T> iterator() {
		return hashmap.keySet().iterator();
	}

	@Override
	public boolean remove(Object element) {
		return hashmap.remove(element, hashmap.get(element));
	}

	@Override
	public boolean removeAll(Collection<?> collection) {
		boolean modified = false;
		ArrayList<Object> array = new ArrayList<>();
		for (T key : hashmap.keySet()) {
			if (collection.contains(key)) {
				array.remove(key);
				modified = true;
				}
			}
		return modified;
	}
	
	@Override
	public boolean retainAll(Collection<?> elements) {
		ArrayList<Object> array = new ArrayList<>();
		for (T key : hashmap.keySet()) {
			if (!elements.contains(key)) {
				array.add(key);
				}
			}
		return this.removeAll(array);
	}

	@Override
	public int size() {
		return hashmap.size();
	}

	@Override
	public Object[] toArray() {
		ArrayList<Map.Entry<T, Integer>> sortedArrayList = sortEntries();
		Object[] sortedArray = new Object[sortedArrayList.size()];
		int i = 0;
		for (Map.Entry<T, Integer> value: sortedArrayList) {
			sortedArray[i] = value.getKey();
			++i;
		}
		return sortedArray;
	}
	
	@Override
	public <S> S[] toArray(S[] array) {
		ArrayList<Map.Entry<T, Integer>> sortedArrayList = sortEntries();
		int i = 0;
		for (Map.Entry<T, Integer> value: sortedArrayList) {
			array[i] = (S) value.getKey();
			++i;
		}
		return array;
	}
	
	@Override
	public String toString() {
		return Arrays.toString(this.toArray());
	}
	
	public ArrayList<Map.Entry<T, Integer>> sortEntries() {
		Set<Map.Entry<T, Integer>> entries = hashmap.entrySet();
		ArrayList<Map.Entry<T, Integer>> entriesList = new ArrayList<>(entries);
		Collections.sort(entriesList, new Comparator<Map.Entry<T, Integer>>() {
			@Override
		    public int compare(Entry<T, Integer> o1, Entry<T, Integer> o2) {
				return o1.getValue().compareTo(o2.getValue());
		    }
		});
		return entriesList;
	}
	
	public static void main(String[] args){
		OccurrenceSet<Integer> intSet = new OccurrenceSet<Integer>();
		intSet.add(1);
		intSet.add(3);
		intSet.add(5);
		intSet.add(5);
		intSet.add(3);
		intSet.add(3);
		intSet.add(3);
		System.out.println(intSet);
		OccurrenceSet<String> stringSet = new OccurrenceSet<String>();
		stringSet.add("hello");
		stringSet.add("hello");
		stringSet.add("world");
		stringSet.add("world");
		stringSet.add("world");
		stringSet.add("here");
		System.out.println(stringSet);
	}

}
