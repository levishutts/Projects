import java.util.Scanner;
import java.util.ArrayList;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class Client {
	private static final int PORT = 1029;
	public static void main(String[] args) throws ClassNotFoundException {
		ArrayList<Integer> intList = new ArrayList();
		Scanner scanner = new Scanner(System.in);
		Socket socket = null;
		ObjectOutputStream outputStream = null;
		ObjectInputStream inputStream = null;
		System.out.println("Enter an integer to add to the list (enter any text to send the list): ");
		while(scanner.hasNext()) {
			if (scanner.hasNextInt()){
				intList.add(scanner.nextInt());
            }
            else {
            	break;
            }
        }
        scanner.close();
        try {
        	InetAddress localInetAddress = InetAddress.getLocalHost();
        	socket = new Socket(localInetAddress, PORT);
         	outputStream = new ObjectOutputStream(socket.getOutputStream());
          	outputStream.flush();
           	inputStream = new ObjectInputStream(socket.getInputStream());
           	outputStream.writeObject(intList);
           	System.out.println("Sending " + intList + " to server");
        	Object primes = inputStream.readObject();
          	ArrayList<Integer> primeList = (ArrayList) primes;
           	System.out.println("Client received list of primes: " + primeList);
        }
        catch (IOException e) {
        	e.printStackTrace();
        }
        finally {
           	try {
            	if (socket != null) {
                  	socket.close();
              	}
            	if (outputStream != null) {
                  	outputStream.close();
              	}
             	if (inputStream != null) {
                  	inputStream.close();
                }
          	}
             	catch (IOException e) {
                  	e.printStackTrace();
              	}
        }
   	}
}