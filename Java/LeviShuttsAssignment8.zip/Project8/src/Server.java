
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {
	private static final int PORT = 1029;
        
    private static boolean isPrime(int n) {
    	// A number is prime if its only divisors are 1 and itself
        if (n == 1) {
        	return false;
        }
        else if (n == 2) {
            return true;
        }
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
            	return false;
            }
        }
        return true;
    }
        
    public static void main(String[] args) throws ClassNotFoundException, IOException {
    	ServerSocket serverSocket = null;
        Socket socket = null;
        ObjectOutputStream outputStream = null;
        ObjectInputStream inputStream = null;
        ArrayList<Integer> intList = new ArrayList();
        ArrayList<Integer> primeArray = new ArrayList();
        try {
        	serverSocket = new ServerSocket(PORT);
            socket = serverSocket.accept();
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            outputStream.flush();
            inputStream = new ObjectInputStream(socket.getInputStream());
            Object intObject = inputStream.readObject();
            intList = (ArrayList<Integer>) intObject;
            for (int i: intList) {
            	if (isPrime(i)) {
            		primeArray.add(i);
                 }
            }
            outputStream.writeObject(primeArray);
            outputStream.flush();
         }
         catch (IOException e) {
        	 e.printStackTrace();
         }
         finally {
        	 try {
        		 if (serverSocket != null) {
        			 serverSocket.close();
                 }
                 if (socket != null) {
                	 socket.close();
                 }
                 if (outputStream != null) {
                	 outputStream.close();
                 }
                 if (inputStream != null) {
                	 inputStream.close();
                 }
        	 }
             catch (IOException e) {
            	 e.printStackTrace();
             }
         }
	}
}