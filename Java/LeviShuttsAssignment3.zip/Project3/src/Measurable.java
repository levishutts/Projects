
public interface Measurable {
	public double getArea();
}
