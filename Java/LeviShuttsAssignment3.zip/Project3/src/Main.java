import java.util.ArrayList;
import java.util.Random;

public class Main{
	
	private static double nextDouble() {
		Random random = new Random();
		double rand = random.nextDouble() + Double.MIN_VALUE;
		return rand;
	}
	private static double calculateSum(ArrayList<Measurable> mList) {
		double total = 0;	
		for (Measurable si : mList) {
			total += si.getArea();
		}
		return total;
	}
	public static void main(String[] args){
		ArrayList<Measurable> list = new ArrayList<Measurable>();
		int rectC = 0, boxC = 0, circC = 0, sphC = 0;
		for (int i = 0; i < 1000; ++i){
			double split = nextDouble();
			if (split <= .25){
				Rectangle rectangle = new Rectangle(nextDouble(), nextDouble());
				list.add(rectangle);
				rectC += 1;
			}else if (split > .25 && split <= .5){
				Box box = new Box(nextDouble(), nextDouble(), nextDouble());
				list.add(box);
				boxC += 1;
			}else if (split > .5 && split <= .75){
				Circle circle = new Circle(nextDouble());
				list.add(circle);
				circC += 1;
			}else {
				Sphere sphere = new Sphere(nextDouble());
				list.add(sphere);
				sphC += 1;
			}
		}
		System.out.println("rects: " + rectC + " boxes: " + boxC + " circles: " + circC + " spheres: " + sphC);
		System.out.println("sum: " + calculateSum(list));
	}
}
