
public class Box extends Rectangle {
	
	private double _length;
	
	public Box(double length, double width, double height) {
		super(width, height);
		_length = length;
	}
	
	@Override
	public double getArea() {
		return (_length * _width) + (_length * _height) + (_width * _height);
	}
}
