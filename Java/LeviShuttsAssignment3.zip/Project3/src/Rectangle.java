
public class Rectangle implements Measurable {
	
	protected double _width;
	protected double _height;
	
	public Rectangle(double width, double height) {
		_width = width;
		_height = height;
	}
	
	@Override
	public double getArea() {
		return _width * _height;
	}
}
