
public class Circle implements Measurable {
	
	protected double _radius;
	
	public Circle(double radius) {
		_radius = radius;
	}
	
	@Override
	public double getArea() {
		return Math.PI * (_radius * _radius);
	}
}