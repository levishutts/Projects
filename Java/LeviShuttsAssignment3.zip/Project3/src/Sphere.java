
public class Sphere extends Circle {
	
	public Sphere(double radius) {
		super(radius);
	}
	
	@Override
	public double getArea() {
		return 4 * (Math.PI * (_radius * _radius));
	}
}
