import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class ConsumerRunnable implements Runnable{
	LinkedBlockingQueue<String> _queue;
	int _id;
	long _MAX_CONSUMER_WAIT_MS;
	
	public ConsumerRunnable(LinkedBlockingQueue<String> queue, int id, long MAX_CONSUMER_WAIT_MS) {
		_queue = queue;
		_id = id;
		_MAX_CONSUMER_WAIT_MS = MAX_CONSUMER_WAIT_MS;
	}
	
	@Override
	public void run() {
		String max = "";
		int consCount = 1;
		boolean looping = true;
		
		while(looping){
			try {
				String n = _queue.poll(_MAX_CONSUMER_WAIT_MS, TimeUnit.MILLISECONDS);
				if (n == null){
					looping = false;
					break;
				}
				consCount += 1;
				if (n.compareTo(max) > 0){
					max = n;
				}
				if (consCount % 1000 == 0) {			
						System.out.println("consumer " + _id + " consumed: " + consCount);	
				}											
				long sleepDelay = (long) (10 * Math.random());
				Thread.sleep(sleepDelay);
			} catch (InterruptedException ex) {
				System.out.println("ConsumerRunnable InterruptedException!!!");
			}
		}			
		System.out.println("consume " + _id + " finished! consumed: " + consCount);
		System.out.println("consumer " + _id + " max string: " + max);
	}
}
