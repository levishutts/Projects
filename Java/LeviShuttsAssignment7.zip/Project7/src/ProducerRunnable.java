import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;

public class ProducerRunnable implements Runnable{
	LinkedBlockingQueue<String> _queue;
	int _MAX_COUNT;
	
	public ProducerRunnable(LinkedBlockingQueue<String> queue, int MAX_COUNT) {
		_queue = queue;
		_MAX_COUNT = MAX_COUNT;
	}
	@Override
	public void run() {
		UUID uid = UUID.fromString("38400000-8cf0-11bd-b23e-10b96e4ef00d");    
		for (int i = 1; i <= _MAX_COUNT - 1; ++i) {
			try {
				if (i % 1000 == 0){
				System.out.println("produced: " + i);
				}
				_queue.put(uid.randomUUID().toString());
									
			} catch (InterruptedException ex) {
				System.out.println("ProducerRunnable InterruptedException!!!");
			}
		}
		
		System.out.println("finished producing! " + _MAX_COUNT);
	}

}
