import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class Main {
	private static final long MAX_CONSUMER_WAIT_MS = 3000;
	private static final int QUEUE_SIZE = 100000;
	private static final int MAX_COUNT = 2000000;
	
	public static void main(String[] args) {			
		LinkedBlockingQueue<String> queue = new LinkedBlockingQueue(QUEUE_SIZE);
		ProducerRunnable producer = new ProducerRunnable(queue, MAX_COUNT);
		ConsumerRunnable consumer1 = new ConsumerRunnable(queue, 1, MAX_CONSUMER_WAIT_MS);
		ConsumerRunnable consumer2 = new ConsumerRunnable(queue, 2, MAX_CONSUMER_WAIT_MS);
		ConsumerRunnable consumer3 = new ConsumerRunnable(queue, 3, MAX_CONSUMER_WAIT_MS);
		
		ExecutorService executor = Executors.newCachedThreadPool();
		executor.execute(producer);
		executor.execute(consumer1);
		executor.execute(consumer2);	
		executor.execute(consumer3);
		executor.shutdown();
	}
}

