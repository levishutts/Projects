import java.util.Scanner;

public class Project1 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int total = 0;
				
		boolean looping = true;
		while (looping){
			System.out.print("Enter a positive integer (-1 to print, -2 to reset, -3 to quit): ");
			int num = scanner.nextInt();
			
			if (num == -1){
				System.out.println("Total = " + total);
			} else if (num == -2){
				total = 0;
			} else if (num == -3){
				System.out.println("Total = " + total);
				looping = false;
			} else if (num > 0){
				total += num;
			} 
		}
		scanner.close();
	}
}