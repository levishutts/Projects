
public class Info {
	private final String _phone;
	private final String _name;
	
	public Info(String phone, String name){
		_phone = phone;
		_name = name;
	}
	
	public String getPhone(){
		return _phone;
	}
	
	public String getName(){
		return _name;
	}
	@Override
	public String toString() {
		return _phone + _name;
	}
}
