import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SortApp extends JFrame implements ActionListener{
	private final JButton _selection;
	private final JButton _merge;
	private static JLabel selectionValue;
	private static JLabel mergeValue;
	
	public SortApp() {
		super("Assignment 5");
		setLayout(new BorderLayout());
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(2, 1));
		
		JPanel labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(2, 1));
		
		_selection = new JButton("Selection Sort");
		_selection.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String elapsed = "";
				try {
					elapsed = Main.timeElapsed(0);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				selectionValue.setText(elapsed);
			}		
		});
		buttonPanel.add(_selection);
		selectionValue = new JLabel("", JLabel.CENTER);
		labelPanel.add(selectionValue);
		
		_merge = new JButton("Merge Sort");
		_merge.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String elapsed = "";
				try {
					elapsed = Main.timeElapsed(1);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				mergeValue.setText(elapsed);
			}	
		});
		buttonPanel.add(_merge);
		mergeValue = new JLabel ("", JLabel.CENTER);
		labelPanel.add(mergeValue);
		
		add((buttonPanel), BorderLayout.WEST);
		add(labelPanel, BorderLayout.CENTER);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
