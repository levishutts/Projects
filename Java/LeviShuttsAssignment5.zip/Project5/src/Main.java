
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;

import java.io.IOException;

public class Main {
	public static ArrayList<Info> fileReader() throws IOException{
		Scanner fileIn = new Scanner(new FileReader("phonebook.txt"));
		ArrayList<Info> list = new ArrayList<Info>();
		while((fileIn.hasNext()))
		{
		    list.add(new Info(fileIn.next(), fileIn.next() + fileIn.next()));
		}
		fileIn.close();
		return list;
	}

	public static ArrayList<Info> selectionSort(ArrayList<Info> list) {
		ArrayList<Info> arr = list;
		for (int i = 0; i < arr.size(); ++i) {
			Info min = arr.get(i);
			for (int j = i; j < arr.size(); ++j) {
				if (arr.get(j).getName().compareTo(min.getName()) < 0) {
					min = arr.get(j);
		        }
		    }
			arr.set(arr.indexOf(min), arr.get(i));
			arr.set(i, min);	
		 }
		 return arr;
	}
	 
	 public static ArrayList<Info> mergeSort(ArrayList<Info> list) {
		 //Got merge sort methods from http://www.codexpedia.com/java/java-merge-sort-implementation/
		    ArrayList<Info> left = new ArrayList<Info>();
		    ArrayList<Info> right = new ArrayList<Info>();
		    ArrayList<Info> arr = list;
		    int center;
		    
		    if (arr.size() == 1) {    
		        return arr;
		    } else {
		        center = arr.size()/2;
		        // copy the left half of whole into the left.
		        for (int i = 0; i < center; i++) {
		                left.add(arr.get(i));
		        }
		 
		        //copy the right half of whole into the new arraylist.
		        for (int i=center; i < arr.size(); i++) {
		                right.add(arr.get(i));
		        }
		 
		        // Sort the left and right halves of the arraylist.
		        left  = mergeSort(left);
		        right = mergeSort(right);
		 
		        // Merge the results back together.
		        merge(left, right, arr);
		    }
		    return arr;
		}
	 private static void merge(ArrayList<Info> left, ArrayList<Info> right, ArrayList<Info> whole) {
		    int leftIndex = 0;
		    int rightIndex = 0;
		    int wholeIndex = 0;
		 
		    // As long as neither the left nor the right ArrayList has
		    // been used up, keep taking the smaller of left.get(leftIndex)
		    // or right.get(rightIndex) and adding it at both.get(bothIndex).
		    while (leftIndex < left.size() && rightIndex < right.size()) {
		        if ( (left.get(leftIndex).getName().compareTo(right.get(rightIndex).getName())) < 0) {
		            whole.set(wholeIndex, left.get(leftIndex));
		            leftIndex++;
		        } else {
		            whole.set(wholeIndex, right.get(rightIndex));
		            rightIndex++;
		        }
		        wholeIndex++;
		    }
		 
		    ArrayList<Info> rest;
		    int restIndex;
		    if (leftIndex >= left.size()) {
		        // The left ArrayList has been use up...
		        rest = right;
		        restIndex = rightIndex;
		    } else {
		        // The right ArrayList has been used up...
		        rest = left;
		        restIndex = leftIndex;
		    }
		 
		    // Copy the rest of whichever ArrayList (left or right) was not used up.
		    for (int i=restIndex; i<rest.size(); i++) {
		        whole.set(wholeIndex, rest.get(i));
		        wholeIndex++;
		    }
		}
	 public static boolean isSorted(ArrayList<Info> list){
	     boolean sorted = true;        
	     for (int i = 1; i < list.size(); i++) {
	         if (list.get(i-1).getName().compareTo(list.get(i).getName()) > 0) sorted = false;
	     }
	     return sorted;
	 }
	public static String timeElapsed(int sortMethod) throws IOException {
		ArrayList<Info> unsorted = fileReader();
		if (sortMethod == 0) {
			final long startTime = System.nanoTime();
			ArrayList<Info> sortedArray = selectionSort(unsorted);
			final double elapsedTime = (System.nanoTime() - startTime) / 1000000000.0;
			if (isSorted(sortedArray)) {
				return Double.toString(elapsedTime);
			}
			else {
				return "Error";
			}
		}
		else if (sortMethod == 1) {
			final long startTime = System.nanoTime();
			ArrayList<Info> sortedArray = mergeSort(unsorted);
			final double elapsedTime = (System.nanoTime() - startTime) / 1000000000.0;
			if (isSorted(sortedArray)) {
				return Double.toString(elapsedTime);
			}
			else {
				return "Error";
			}
		}
		return "";
	}
	 
	public static void main(String[] args) throws IOException{
		
		SortApp frame = new SortApp();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
	}
}
