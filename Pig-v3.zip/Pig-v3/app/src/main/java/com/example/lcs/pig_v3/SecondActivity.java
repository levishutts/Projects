package com.example.lcs.pig_v3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by lcs on 7/11/2017.
 */
public class SecondActivity extends AppCompatActivity {

    private TextView player1Score;
    private TextView player2Score;
    private TextView playerTurnLabel;
    private ImageView dieImageView;
    private TextView turnScoreTextView;
    private Button rollButton;
    private Button endTurnButton;

    private SharedPreferences prefs;

    private Game game;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.second_activity);
        //  setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        //  getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (savedInstanceState != null)
            Toast.makeText(this, savedInstanceState.getString("test", "huh?"),
                    Toast.LENGTH_LONG).show();

        //get references
        player1Score = (TextView) findViewById(R.id.player1Score);
        player2Score = (TextView) findViewById(R.id.player2Score);
        playerTurnLabel = (TextView) findViewById(R.id.playerTurnLabel);
        dieImageView = (ImageView) findViewById(R.id.dieImageView);
        turnScoreTextView = (TextView) findViewById(R.id.turnScoreTextView);
        rollButton = (Button) findViewById(R.id.rollButton);
        endTurnButton = (Button) findViewById(R.id.endTurnButton);

        //Set listeners


        //create Game object
        game = new Game();
    }

    @Override
    public void onResume() {
        super.onResume();

        // Get the game state sent from the FirstActivity
        Intent intent = getIntent();
        String player1Name = intent.getExtras().getString("player1Name");
        String player2Name = intent.getExtras().getString("player2Name");
        if (game == null)   // We might already have a game object
            game = new Game();
        game.newGame();
        game.setPlayerName(player1Name, 1);
        game.setPlayerName(player2Name, 2);
        // Pass the fragment a game ref while calling the method invokes game play
        SecondFragment secondFragment = (SecondFragment) getFragmentManager()
                .findFragmentById(R.id.second_fragment);
        secondFragment.playGame(game);
    }
}